$(document).ready(function () {
	//Global variable.
	var SpeechEncode;
	var CustomQuery;
	var DrillDownApp;
	var DrillDownTime;
	var accessToken = "371ea65f7cbb48f38233504667111509";
	var Appid = ["AP016", "AP007", "AP006", "AP005", "AP009", "AP003", "AP014", "AP008", "AP015", "AP001", "AP004", "AP017", "AP018", "AP025", "AP010", "AP011", "AP012", "AP013"];
	var ToolId = ["TL001", "TL002", "TL003", "TL004", "TL005", "TL006", "TL007", "TL008", "TL009", "TL010", "TL011", "TL012"];
	var DrillDownId = ["1", "2", "3", "4", "5"];
	var isfromContinuousListening = false;
	//Sample Utterance
	var messageCouldntHear = "I couldn't hear you, could you please touch the screen?";
	var LabelResult = [];
	var DataResultCount = [];
	var DataResultHighSeverity = [];
	var DataResultMediumSeverity = [];
	var DataResultLowSeverity = [];
	var recCount = [];
	var loc;
	var setIntervalVar;
	// Service Variable.
	var GavelServiceAPI = "http://gaveldev.gavstech.com:8081/gavel-chatbot/#/";
	//var GavelServiceAPI = "https://gaveludpp.icicibankltd.com:8443/gavel-chatbot/#/";
	var GoogleSpeechAPI = "https://speech.googleapis.com/v1beta1/speech:syncrecognize?key=AIzaSyDq6NlY6RSh70enCPCdE00QTlZM636p2RY";
	var DialogflowAPI = "https://api.dialogflow.com/v1/query?v=20150910";
	var GoogleTextAPI = "https://texttospeech.googleapis.com/v1beta1/text:synthesize?key=AIzaSyDq6NlY6RSh70enCPCdE00QTlZM636p2RY";
	$('#loading').hide();
	$("#txtspeech").attr('readonly', true);
	$(document).on("click", "#record", function () {
		EnableMicRecording();
	});
	function EnableMicRecording() {
		$('#TextToDisplay').hide();
		$("#txtspeech").val("");
		//Live Speech record.
		Fr.voice.record($("#live").is(":checked"), function () {
			console.log("start recording");
			$('#loading').show(); // Visible the gif for while speaking.
			$("#txtspeech").val("");
		});
		// Stop Recording Speech.
		Fr.voice.stopRecordingAfter(6000, function () {
			console.log("Recording stopped after 6 seconds");
			$('#loading').hide(); // In-Visible the gif after speak.
			EncodebaseURL();
			$("#txtspeech").show();			
		});
	}
	$("body").click(function () {
		EnableMicRecording();
	});
	// Convert Speech or Audio to Base64 format.
	function EncodebaseURL() {
		Fr.voice.export(function (url) {
			console.log("Converted base64 URL");
			SpeechEncode = url;
			callSpeechAPI();
		}, "base64");
	}
	// Google Speech to text Method.
	function callSpeechAPI() {
		console.log("Calling Google API");
		var AudioContentEncode = SpeechEncode.split(",");
		// Create the json object.
		var JsonObject = {
			config:
				{ language_code: 'en-IN' },
			audio:
				{ content: AudioContentEncode[1] }
		};
		var SpeechJson = JSON.stringify(JsonObject);
		// Google API Post Method.
		$.ajax({
			type: "POST",
			url: GoogleSpeechAPI,
			data: SpeechJson,
			contentType: "application/json;",
			dataType: "json",
			success: function (data, status) {   // success callback function				
				console.log(status);
				if (data.results == undefined) {
					if (!isfromContinuousListening) {
						CallCouldntHear();
					}
					else {
						isfromContinuousListening = false;
						$('#TextToDisplay').show();
					}
				}
				else {
					CustomQuery = data.results[0].alternatives[0].transcript;
					console.log(CustomQuery);
					$("#txtspeech").val(CustomQuery);
					CallDialogflowAPI();
				}
			},
			error: function (textStatus, errorMessage) { // error callback 
				console.log(errorMessage);
			}
		});
	}
	function CallCouldntHear() {
		console.log("User Did not Speak");
		var spokenResponse = messageCouldntHear;
		CallTextAPI(spokenResponse);
		$('#TextToDisplay').show();
		$("#txtspeech").val("");		
	}
	// Google Text to Speech Method
	function CallTextAPI(Texttospeech) {
		console.log("Calling Text API");
		var jsontextobject =
			{
				input: {
					text: Texttospeech,
				},
				voice: {
					languageCode: "en-US",
					name: "en-US-Wavenet-C",
					ssmlGender: "FEMALE"
				},
				audioConfig: {
					audioEncoding: "MP3"
				}
			}
		var textJson = JSON.stringify(jsontextobject);
		// Google API Post Method.
		$.ajax({
			type: "POST",
			url: GoogleTextAPI,
			data: textJson,
			contentType: "application/json;",
			dataType: "json",
			success: function (data, status) {   // success callback function
				console.log(status);
				PayerStream(data);
			},
			error: function (textStatus, errorMessage) { // error callback 
				console.log(errorMessage);
			}
		});
	}
	function PayerStream(data) {
		var audio = document.getElementById('audio');
		audio.src = "data:audio/mp3;base64," + data.audioContent;
		audio.load();
		audio.play();
	}
	// Dialogflow API Post Method.
	function CallDialogflowAPI() {
		console.log("Calling Dialogflow API");
		$.ajax({
			type: "POST",
			url: DialogflowAPI + "query",
			contentType: "application/json;",
			dataType: "json",
			headers: { "Authorization": "Bearer " + accessToken },
			data: JSON.stringify({ query: CustomQuery, lang: "en", sessionId: "test" }),
			success: function (data, status) {// success callback function
				prepareResponse(data);
				console.log(status);
			},
			error: function (textStatus, errorMessage) {// error callback 
				console.log(errorMessage);
			}
		});
	}
	function KeepListening() {
		setTimeout(function () {
			EnableMicRecording();
			isfromContinuousListening = true;
		}, 5000);		
	}
	function PageRefresh(loc) {
		setIntervalVar = setInterval(function () {
			console.log("From Page refresh");
			console.log(Date() + " Calling the url after 2 minutes: " + loc);
			document.getElementById('myFrame').setAttribute('src', "");
			document.getElementById('myFrame').setAttribute('src', loc);
			document.getElementById('myFrame').contentWindow.location.reload(true);
			document.getElementById('myFrame').contentWindow.location.replace(loc);
		}, 120000);
	}
	function myStopFunction() {
		clearTimeout(setIntervalVar);
	}
	// Get resposne from Dialogflow API Post Method.
	function prepareResponse(val) {
		console.log("Getting resposne from Dialogflow API");
		var debugJSON = JSON.stringify(val, undefined, 2);
		var spokenResponse = val.result.fulfillment.speech;
		var IntentName = val.result.metadata.intentName;
		var AppName = val.result.parameters.applications;
		var Timeperiod = val.result.parameters.timings;
		var Resource = val.result.parameters.resources;
		var AppTools = val.result.parameters.tools;
		var Levels = val.result.parameters.levels;
		var Risks = val.result.parameters.risk;
		var NoofDay = val.result.parameters.days;
		
		if (val.result.contexts.length == 1) {
			DrillDownApp = val.result.contexts[0].parameters.applications;
			DrillDownTime = val.result.contexts[0].parameters.timings;
		}

		if (val.result.contexts.length > 1) {
			DrillDownTime = val.result.contexts[1].parameters.timings;
			DrillDownApp = val.result.contexts[1].parameters.applications;
		}
		var SmallTalk = val.result.action;

		if (IntentName != "" && IntentName != null) {
			CallTextAPI(spokenResponse);
			intentMatch(IntentName, AppName, Timeperiod, Resource, DrillDownApp, DrillDownTime, AppTools, Levels, NoofDay);
			KeepListening();
		}
		else if (SmallTalk != "") {
			myStopFunction();
			CallTextAPI(spokenResponse);
			document.getElementById('myFrame').setAttribute('src', "");
		}
	}
	function getTimePeriod(TimePeriod) {
		var timeperiod = TimePeriod.split(" ");
		if (timeperiod[0] == 24)
			timeperiod[0] = 6;
		else if (timeperiod[0] == 8)
			timeperiod[0] = 5;
		return timeperiod;
	}
	function getToolName(AlertsToolsMonitoring) {
		var toolName;
		var toolAlertUrl = "allalerts?appId=all&toolID=";
		if (AlertsToolsMonitoring.toLowerCase() == "apm") {
			toolName = toolAlertUrl + "TL001,TL002,TL006&appName=APM";
		}
		else if (AlertsToolsMonitoring.toLowerCase() == "db") {
			toolName = toolAlertUrl + "TL003&appName=Database";
		}
		else if (AlertsToolsMonitoring.toLowerCase() == "server") {
			toolName = toolAlertUrl + "TL007,TL009,TL010,TL011&appName=Server";
		}
		else if (AlertsToolsMonitoring.toLowerCase() == "network") {
			toolName = toolAlertUrl + "TL004,TL008,TL012&appName=Network";
		}
		else if (AlertsToolsMonitoring.toLowerCase() == "storage") {
			toolName = toolAlertUrl + "TL005&appName=Storage";
		}
		else
			toolName = "allalerts?appId=all&toolName=" + AlertsToolsMonitoring;
		return toolName;
	}
	function GetSystemDate(Noofdays) {
		var dayscount = Noofdays.split(" ");
		var today = new Date();
		var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - dayscount[0]);
		var currentYear = today.getFullYear();
		var currentMonth = today.getMonth() + 1;
		var curreentDay = today.getDate();
		var CurrentDate = ("0000" + currentYear.toString()).slice(-4) + "-" + ("00" + currentMonth.toString()).slice(-2) + "-" + ("00" + curreentDay.toString()).slice(-2);

		var lastWeekMonth = lastWeek.getMonth() + 1;
		var lastWeekDay = lastWeek.getDate();
		var lastWeekYear = lastWeek.getFullYear();

		var lastWeekDate = ("0000" + lastWeekYear.toString()).slice(-4) + "-" + ("00" + lastWeekMonth.toString()).slice(-2) + "-" + ("00" + lastWeekDay.toString()).slice(-2);
		var fromDate = lastWeekDate + "T00:00:00Z";
		var toDate = CurrentDate + "T23:59:59Z";

		return "fromDate=" + fromDate + "&toDate=" + toDate;
	}
	function OverallHealth(Timeperiod, NoofDay) {		
		if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
			var dateurl = GetSystemDate(NoofDay);
			loc = GavelServiceAPI + "overAllChart?state=all&" + dateurl + "&viewPoints=1";
		}
		else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
			var timeperiod = getTimePeriod(Timeperiod);
			loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
		}
		else {
			loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
		}
		document.getElementById('myFrame').setAttribute('src', loc);
	}
	function ApplicationSummary(AppName, Timeperiod, NoofDay) {		
		if (AppName != null && AppName != "") {
			if (AppName.includes("3DSecure"))
				AppName = "3D Secure";
			else if (AppName.includes("DBP"))
				AppName = "Digital Banking Pockets";
			else if (AppName.includes("iCore"))
				AppName = "iCore India";
			else if (AppName.includes("iLoans"))
				AppName = "iLoans India";
			else if (AppName.includes("iCards"))
				AppName = "I Cards Online 4";

			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&" + dateurl + "&viewPoints=1";
			}
			else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
			}
			else {
				loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
			}
			document.getElementById('myFrame').setAttribute('src', loc);
		}
	}
	function ApplicationStatus(AppName, Timeperiod, NoofDay) {		
		if (AppName != null && AppName != "") {
			if (AppName.includes("3DSecure"))
				AppName = "3D Secure";
			else if (AppName.includes("DBP"))
				AppName = "Digital Banking Pockets";
			else if (AppName.includes("iCore"))
				AppName = "iCore India";
			else if (AppName.includes("iLoans"))
				AppName = "iLoans India";
			else if (AppName.includes("iCards"))
				AppName = "I Cards Online 4";

			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&" + dateurl + "&viewPoints=1";
			}
			else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
			}
			else {
				loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
			}
			document.getElementById('myFrame').setAttribute('src', loc);
		}
	}
	function OverallRiskAndAppRisk(AppName, DrillDownApp, Timeperiod, DrillDownTime) {		
		if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
			if (DrillDownApp != null && DrillDownApp != "" && AppName == null) {
				AppName = DrillDownApp;
			}
			if (AppName.includes("3DSecure"))
				AppName = "3D Secure";
			else if (AppName.includes("DBP"))
				AppName = "Digital Banking Pockets";
			else if (AppName.includes("iCore"))
				AppName = "iCore India";
			else if (AppName.includes("iLoans"))
				AppName = "iLoans India";
			else if (AppName.includes("iCards"))
				AppName = "I Cards Online 4";

			if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
				var timeperiod;
				if (Timeperiod != null && Timeperiod != "")
					timeperiod = getTimePeriod(Timeperiod);
				else
					timeperiod = getTimePeriod(DrillDownTime);
				loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
			}
			else {
				loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
			}
			document.getElementById('myFrame').setAttribute('src', loc);
		}
	}
	function AppStatusAndAlerts(AppName, DrillDownApp, Timeperiod, DrillDownTime, NoofDay) {		
		if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
			var APPID;
			if (DrillDownApp != null && DrillDownApp != "" && AppName == null) {
				AppName = DrillDownApp;
			}
			if (AppName.includes("3DSecure")) {
				AppName = "3D Secure";
				APPID = Appid[5];
			}
			else if (AppName.includes("DBP")) {
				AppName = "Digital Banking Pockets";
				APPID = Appid[3];
			}
			else if (AppName.includes("iCore")) {
				AppName = "iCore India";
				APPID = Appid[10];
			}
			else if (AppName.includes("iLoans")) {
				AppName = "iLoans India";
				APPID = Appid[9];
			}
			else if (AppName.includes("iCards")) {
				AppName = "I Cards Online 4";
				APPID = Appid[16];
			}
			else if (AppName.includes("SMS Gateway"))
				APPID = Appid[0];
			else if (AppName.includes("iView"))
				APPID = Appid[1];
			else if (AppName.includes("RIB"))
				APPID = Appid[2];
			else if (AppName.includes("IMPS"))
				APPID = Appid[4];
			else if (AppName.includes("Riskfort"))
				APPID = Appid[6];
			else if (AppName.includes("iMobile"))
				APPID = Appid[7];
			else if (AppName.includes("Webfort"))
				APPID = Appid[8];
			else if (AppName.includes("EAI"))
				APPID = Appid[11];
			else if (AppName.includes("IAI"))
				APPID = Appid[12];
			else if (AppName.includes("UPI"))
				APPID = Appid[13];
			else if (AppName.includes("CAR"))
				APPID = Appid[14];
			else if (AppName.includes("UBPS"))
				APPID = Appid[15];

			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "allalerts?appId=" + APPID + "&appName=" + AppName + "&" + dateurl + "&viewPoints=1";
			}
			else if ((Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") || (DrillDownTime != null && DrillDownTime != "")) {
				var timeperiod;
				if (Timeperiod != null && Timeperiod != "")
					timeperiod = getTimePeriod(Timeperiod);
				else
					timeperiod = getTimePeriod(DrillDownTime);

				loc = GavelServiceAPI + "allalerts?appId=" + APPID + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
			}
			else {
				loc = GavelServiceAPI + "allalerts?appId=" + APPID + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
			}
			document.getElementById('myFrame').setAttribute('src', loc);
		}
	}
	function AppStatusAndCorrelation(AppName, DrillDownApp, Timeperiod, DrillDownTime, NoofDay) {		
		if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
			var APPID;
			if (DrillDownApp != null && DrillDownApp != "" && AppName == null) {
				AppName = DrillDownApp;
			}
			if (AppName.includes("3DSecure")) {
				AppName = "3D Secure";
				APPID = Appid[5];
			}
			else if (AppName.includes("DBP")) {
				AppName = "Digital Banking Pockets";
				APPID = Appid[3];
			}
			else if (AppName.includes("iCore")) {
				AppName = "iCore India";
				APPID = Appid[10];
			}
			else if (AppName.includes("iLoans")) {
				AppName = "iLoans India";
				APPID = Appid[9];
			}
			else if (AppName.includes("iCards")) {
				AppName = "I Cards Online 4";
				APPID = Appid[16];
			}
			else if (AppName.includes("SMS Gateway"))
				APPID = Appid[0];
			else if (AppName.includes("iView"))
				APPID = Appid[1];
			else if (AppName.includes("RIB"))
				APPID = Appid[2];
			else if (AppName.includes("IMPS"))
				APPID = Appid[4];
			else if (AppName.includes("Riskfort"))
				APPID = Appid[6];
			else if (AppName.includes("iMobile"))
				APPID = Appid[7];
			else if (AppName.includes("Webfort"))
				APPID = Appid[8];
			else if (AppName.includes("EAI"))
				APPID = Appid[11];
			else if (AppName.includes("IAI"))
				APPID = Appid[12];
			else if (AppName.includes("UPI"))
				APPID = Appid[13];
			else if (AppName.includes("CAR"))
				APPID = Appid[14];
			else if (AppName.includes("UBPS"))
				APPID = Appid[15];

			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "correlationLists?alertId=" + APPID + "&" + dateurl + "&viewPoints=1";
			}

			else if ((Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") || (DrillDownTime != null && DrillDownTime != "")) {
				var timeperiod;
				if (Timeperiod != null && Timeperiod != "")
					timeperiod = getTimePeriod(Timeperiod);
				else
					timeperiod = getTimePeriod(DrillDownTime);
				loc = GavelServiceAPI + "correlationLists?alertId=" + APPID + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
			}
			else {
				loc = GavelServiceAPI + "correlationLists?alertId=" + APPID + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
			}
			document.getElementById('myFrame').setAttribute('src', loc);
		}
		else {
			loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=3&viewPoints=1";
			document.getElementById('myFrame').setAttribute('src', loc);
		}
	}
	function TopIssues(AppName, Timeperiod, NoofDay) {
		var APPID;		
		if (AppName != null && AppName != "") {
			if (AppName.includes("3DSecure"))
				APPID = Appid[5];
			else if (AppName.includes("DBP"))
				APPID = Appid[3];
			else if (AppName.includes("iCore"))
				APPID = Appid[10];
			else if (AppName.includes("iLoans"))
				APPID = Appid[9];
			else if (AppName.includes("iCards"))
				APPID = Appid[16];
			else if (AppName.includes("SMS Gateway"))
				APPID = Appid[0];
			else if (AppName.includes("iView"))
				APPID = Appid[1];
			else if (AppName.includes("RIB"))
				APPID = Appid[2];
			else if (AppName.includes("IMPS"))
				APPID = Appid[4];
			else if (AppName.includes("Riskfort"))
				APPID = Appid[6];
			else if (AppName.includes("iMobile"))
				APPID = Appid[7];
			else if (AppName.includes("Webfort"))
				APPID = Appid[8];
			else if (AppName.includes("EAI"))
				APPID = Appid[11];
			else if (AppName.includes("IAI"))
				APPID = Appid[12];
			else if (AppName.includes("UPI"))
				APPID = Appid[13];
			else if (AppName.includes("CAR"))
				APPID = Appid[14];
			else if (AppName.includes("UBPS"))
				APPID = Appid[15];

			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "top10Issues?appId=" + APPID + "&" + dateurl + "&viewPoints=1";
			}
			else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "top10Issues?appId=" + APPID + "&timePeriod=" + timeperiod[0];
			}
			else
				loc = GavelServiceAPI + "top10Issues?appId=" + APPID + "&timePeriod=3";
			document.getElementById('myFrame').setAttribute('src', loc);
		}
		else {
			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "top10Issues?" + dateurl + "&viewPoints=1";
			}
			else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "top10Issues?timePeriod=" + timeperiod[0];
			}
			else
				loc = GavelServiceAPI + "top10Issues?timePeriod=3";
			document.getElementById('myFrame').setAttribute('src', loc);
		}
	}
	function overall_riskAppRisk_Alerts(AppName, DrillDownApp, Timeperiod, DrillDownTime, NoofDay) {		
		if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
			var APPID;
			if (DrillDownApp != null && DrillDownApp != "" && AppName == null) {
				AppName = DrillDownApp;
			}
			if (AppName.includes("3DSecure")) {
				AppName = "3D Secure";
				APPID = Appid[5];
			}
			else if (AppName.includes("DBP")) {
				AppName = "Digital Banking Pockets";
				APPID = Appid[3];
			}
			else if (AppName.includes("iCore")) {
				AppName = "iCore India";
				APPID = Appid[10];
			}
			else if (AppName.includes("iLoans")) {
				AppName = "iLoans India";
				APPID = Appid[9];
			}
			else if (AppName.includes("iCards")) {
				AppName = "I Cards Online 4";
				APPID = Appid[16];
			}
			else if (AppName.includes("SMS Gateway"))
				APPID = Appid[0];
			else if (AppName.includes("iView"))
				APPID = Appid[1];
			else if (AppName.includes("RIB"))
				APPID = Appid[2];
			else if (AppName.includes("IMPS"))
				APPID = Appid[4];
			else if (AppName.includes("Riskfort"))
				APPID = Appid[6];
			else if (AppName.includes("iMobile"))
				APPID = Appid[7];
			else if (AppName.includes("Webfort"))
				APPID = Appid[8];
			else if (AppName.includes("EAI"))
				APPID = Appid[11];
			else if (AppName.includes("IAI"))
				APPID = Appid[12];
			else if (AppName.includes("UPI"))
				APPID = Appid[13];
			else if (AppName.includes("CAR"))
				APPID = Appid[14];
			else if (AppName.includes("UBPS"))
				APPID = Appid[15];

			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "allalerts?appId=" + APPID + "&appName=" + AppName + "&" + dateurl + "&viewPoints=1";
			}
			else if ((Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") || (DrillDownTime != null && DrillDownTime != "")) {
				var timeperiod;
				if (Timeperiod != null && Timeperiod != "")
					timeperiod = getTimePeriod(Timeperiod);
				else
					timeperiod = getTimePeriod(DrillDownTime);
				loc = GavelServiceAPI + "allalerts?appId=" + APPID + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
			}
			else {
				loc = GavelServiceAPI + "allalerts?appId=" + APPID + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
			}
			document.getElementById('myFrame').setAttribute('src', loc);
		}
		else {
			loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=3&viewPoints=1";
			document.getElementById('myFrame').setAttribute('src', loc);
		}
	}
	function overall_riskAppRisk_Correlations(AppName, DrillDownApp, Timeperiod, DrillDownTime, NoofDay) {		
		if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
			var APPID;
			if (DrillDownApp != null && DrillDownApp != "" && AppName == null) {
				AppName = DrillDownApp;
			}
			if (AppName.includes("3DSecure")) {
				AppName = "3D Secure";
				APPID = Appid[5];
			}
			else if (AppName.includes("DBP")) {
				AppName = "Digital Banking Pockets";
				APPID = Appid[3];
			}
			else if (AppName.includes("iCore")) {
				AppName = "iCore India";
				APPID = Appid[10];
			}
			else if (AppName.includes("iLoans")) {
				AppName = "iLoans India";
				APPID = Appid[9];
			}
			else if (AppName.includes("iCards")) {
				AppName = "I Cards Online 4";
				APPID = Appid[16];
			}
			else if (AppName.includes("SMS Gateway"))
				APPID = Appid[0];
			else if (AppName.includes("iView"))
				APPID = Appid[1];
			else if (AppName.includes("RIB"))
				APPID = Appid[2];
			else if (AppName.includes("IMPS"))
				APPID = Appid[4];
			else if (AppName.includes("Riskfort"))
				APPID = Appid[6];
			else if (AppName.includes("iMobile"))
				APPID = Appid[7];
			else if (AppName.includes("Webfort"))
				APPID = Appid[8];
			else if (AppName.includes("EAI"))
				APPID = Appid[11];
			else if (AppName.includes("IAI"))
				APPID = Appid[12];
			else if (AppName.includes("UPI"))
				APPID = Appid[13];
			else if (AppName.includes("CAR"))
				APPID = Appid[14];
			else if (AppName.includes("UBPS"))
				APPID = Appid[15];

			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "correlationLists?alertId=" + APPID + "&" + dateurl + "&viewPoints=1";
			}
			else if ((Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") || (DrillDownTime != null && DrillDownTime != "")) {
				var timeperiod;
				if (Timeperiod != null && Timeperiod != "")
					timeperiod = getTimePeriod(Timeperiod);
				else
					timeperiod = getTimePeriod(DrillDownTime);
				loc = GavelServiceAPI + "correlationLists?alertId=" + APPID + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
			}
			else {
				loc = GavelServiceAPI + "correlationLists?alertId=" + APPID + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
			}
			document.getElementById('myFrame').setAttribute('src', loc);
		}
		else {
			loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=3&viewPoints=1";
			document.getElementById('myFrame').setAttribute('src', loc);
		}
	}
	// Dialogflow intent name matching.
	function intentMatch(IntentName, AppName, Timeperiod, Resource, DrillDownApp, DrillDownTime, AppTools, Levels, NoofDay) {
		// graph Use case   	
		myStopFunction();
		if (IntentName == "Default Fallback Intent") {
		}
		else if (IntentName == "clear_page") {
			document.getElementById('myFrame').setAttribute('src', "");
			EnableMicRecording();
			isfromContinuousListening = true;
		}
		else if (IntentName == "tool_alerts") {
			var toolAlertUrl = "allalerts?appId=all&toolName=";
			var viewpointsUrl = "&viewPoints=1";
			if (AppTools != "") {
				var AppToolsName = getToolName(AppTools);
				if ((Timeperiod != null && Timeperiod != "") && (Levels != null && Levels != "")) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + AppToolsName + "&timePeriod=" + timeperiod[0] + "&severity=" + Levels + viewpointsUrl;
				}
				else if (NoofDay != "" && NoofDay != null && NoofDay != "undefined") {
					var dateurl = GetSystemDate(NoofDay);
					if (Levels != null && Levels != "") {
						loc = GavelServiceAPI + AppToolsName + "&" + dateurl + "&severity=" + Levels + viewpointsUrl;
					}
					else
						loc = GavelServiceAPI + AppToolsName + "&" + dateurl + "&viewPoints=1";
				}
				else if (Levels != null && Levels != "") {
					loc = GavelServiceAPI + AppToolsName + "&timePeriod=3" + "&severity=" + Levels + viewpointsUrl;
				}
				else if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + AppToolsName + "&timePeriod=" + timeperiod[0] + viewpointsUrl;
				}
				else
					loc = GavelServiceAPI + AppToolsName + "&timePeriod=3" + viewpointsUrl;
				document.getElementById('myFrame').setAttribute('src', loc);
			}
		}
		else if (IntentName == "heatmap") {			
			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "heatmap?" + dateurl + "&viewPoints=1";
			}
			else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "heatmap?timePeriod=" + timeperiod[0] + "&viewPoints=1";
			}
			else
				loc = GavelServiceAPI + "heatmap?timePeriod=3&viewPoints=1";
			document.getElementById('myFrame').setAttribute('src', loc);
		}
		else if (IntentName == "overall_health") {
			OverallHealth(Timeperiod, NoofDay);
		}
		else if (IntentName == "top10issues") {
			TopIssues(AppName, Timeperiod, NoofDay);
		}
		else if (IntentName == "overall_correlation") {			
			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "correlationLists?alertId=ALL" + dateurl + "&viewPoints=1";
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=" + timeperiod[0];
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else {
				loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=3";
				document.getElementById('myFrame').setAttribute('src', loc);
			}
		}
		else if (IntentName == "overall_appsummary") {			
			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "alertsChart?state=all&" + dateurl + "&viewPoints=1";
			}
			else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "alertsChart?state=all&timePeriod=" + timeperiod[0];
			}
			else {
				loc = GavelServiceAPI + "alertsChart?state=all&timePeriod=3";
			}
			document.getElementById('myFrame').setAttribute('src', loc);
		}
		else if (IntentName == "application_summary") {
			ApplicationSummary(AppName, Timeperiod, NoofDay);
		}
		else if (IntentName == "overall_appstatus") {			
			if ((NoofDay != null) && (NoofDay != "") && (NoofDay != "undefined")) {
				var dateurl = GetSystemDate(NoofDay);
				loc = GavelServiceAPI + "appsChart?state=all&" + dateurl + "&viewPoints=1";
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else if (Timeperiod != null && Timeperiod != "" && Timeperiod != "undefined") {
				loc = GavelServiceAPI + "appsChart?state=all&timePeriod=" + timeperiod[0];
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else {
				loc = GavelServiceAPI + "appsChart?state=all&timePeriod=3";
				document.getElementById('myFrame').setAttribute('src', loc);
			}
		}
		else if (IntentName == "application_status") {
			ApplicationStatus(AppName, Timeperiod, NoofDay);
		}
		else if (IntentName == "application_status - alerts" || IntentName == "app_alerts") {
			AppStatusAndAlerts(AppName, DrillDownApp, Timeperiod, DrillDownTime, NoofDay);
		}
		else if (IntentName == "application_status - correlations" || IntentName == "app_correlations") {
			AppStatusAndCorrelation(AppName, DrillDownApp, Timeperiod, DrillDownTime, NoofDay);
		}
		else if (IntentName == "overall_risk") {			
			if (Timeperiod != null && Timeperiod != "") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "riskApps?dateTime=" + timeperiod[0];
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else {
				loc = GavelServiceAPI + "riskApps";
				document.getElementById('myFrame').setAttribute('src', loc);
			}
		}
		else if (IntentName == "application_risks") {			
			if (AppName != null && AppName != "") {
				var ApplicationName = "SMS Gateway";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[1] + "&appName=SMS Gateway&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[5] + "&appName=3D Secure&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[6] + "&appName=3D Secure&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[9] + "&appName=iLoans India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[10] + "&appName=iCore India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[17] + "&appName=I Cards Online 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}
			else {
				if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				else
					loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=3&viewPoints=1";
				document.getElementById('myFrame').setAttribute('src', loc);
			}
		}
		else if (IntentName == "overall_risk-applicationrisk") {
			OverallRiskAndAppRisk(AppName, DrillDownApp, Timeperiod, DrillDownTime);
		}
		else if (IntentName == "overall_risk-applicationrisk_alerts") {
			overall_riskAppRisk_Alerts(AppName, DrillDownApp, Timeperiod, DrillDownTime, NoofDay);
		}
		else if (IntentName == "overall_risk-applicationrisk_correlations") {
			overall_riskAppRisk_Correlations(AppName, DrillDownApp, Timeperiod, DrillDownTime, NoofDay);
		}
		DrillDownApp = "";
		DrillDownTime = "";
		if (loc != "" && loc != undefined)
			PageRefresh(loc);
	}
});