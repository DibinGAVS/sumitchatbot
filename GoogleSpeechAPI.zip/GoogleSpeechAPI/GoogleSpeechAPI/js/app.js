
$(document).ready(function(){
 
    var Audiocontents;
  $(document).on("click", "#recordFor5:not(.disabled)", function () {
      Fr.voice.record($("#live").is(":checked"), function () {
          console.log("start recording");
    });
    Fr.voice.stopRecordingAfter(5000, function(){
        alert("Recording stopped after 5 seconds");
        EncodebaseURL();
    });
  });

  function EncodebaseURL()
  {
      Fr.voice.export(function (url) {
          console.log("Here is the base64 URL : " + url);
          alert("Check the web console for the URL");
          Audiocontents = url;
      }, "base64");
  }

});
