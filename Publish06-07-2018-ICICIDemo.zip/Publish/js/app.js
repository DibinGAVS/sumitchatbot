
$(document).ready(function () {

	//Global variable.
	var SpeechEncode;
	var CustomQuery;
	var DrillDownApp;
	var DrillDownTime;
	var accessToken = "269e55a055294af4beafef7a10ab2fad";
	var Appid = ["AP016", "AP007", "AP006", "AP005", "AP009", "AP003", "AP014", "AP008", "AP015", "AP001", "AP004", "AP017", "AP018", "AP025", "AP010", "AP011", "AP012", "AP013"];
	var DrillDownId = ["1", "2", "3", "4", "5"];

	//Sample Utterance
	var messageCouldntHear = "I couldn't hear you, could you please touch the screen?";

	// Service Variable.
	var GavelServiceAPI = "http://gaveludpp.icicibankltd.com:8080/gavel-chatbot/#/";
	var GoogleSpeechAPI = "https://speech.googleapis.com/v1beta1/speech:syncrecognize?key=AIzaSyDq6NlY6RSh70enCPCdE00QTlZM636p2RY";
	var DialogflowAPI = "https://api.dialogflow.com/v1/query?v=20150910";
	var GoogleTextAPI = "https://texttospeech.googleapis.com/v1beta1/text:synthesize?key=AIzaSyDq6NlY6RSh70enCPCdE00QTlZM636p2RY";

	$('#loading').hide();
	$("#txtspeech").attr('readonly', true);
	$(document).on("click", "#record", function () {
		EnableMicRecording();
	});

	function EnableMicRecording() {
		$('#TextToDisplay').hide();
		//Live Speech record.
		Fr.voice.record($("#live").is(":checked"), function () {
			console.log("start recording");
			$('#loading').show(); // Visible the gif for while speaking.
			$("#txtspeech").val("");
			document.getElementById('myFrame').setAttribute('src', "");
		});
		// Stop Recording Speech.
		Fr.voice.stopRecordingAfter(4000, function () {
			console.log("Recording stopped after 4 seconds");
			$('#loading').hide(); // In-Visible the gif after speak.
			EncodebaseURL();
			$("#txtspeech").show();
			//$('#TextToDisplay').show();
		});
	}

	$("body").click(function () {
		EnableMicRecording();
	});

	// Convert Speech or Audio to Base64 format.
	function EncodebaseURL() {
		Fr.voice.export(function (url) {
			console.log("Converted base64 URL");
			SpeechEncode = url;
			callSpeechAPI();
		}, "base64");
	}
	// Google Speech to text Method.
	function callSpeechAPI() {
		console.log("Calling Google API");
		var AudioContentEncode = SpeechEncode.split(",");
		// Create the json object.
		var JsonObject = {
			config:
				{ language_code: 'en-IN' },
			audio:
				{ content: AudioContentEncode[1] }
		};

		var SpeechJson = JSON.stringify(JsonObject);

		// Google API Post Method.
		$.ajax({
			type: "POST",
			url: GoogleSpeechAPI,
			data: SpeechJson,
			contentType: "application/json;",
			dataType: "json",
			success: function (data, status) {   // success callback function
				console.log(status);
				if (data.results == undefined) {
					CallCouldntHear();
				}
				else {
					CustomQuery = data.results[0].alternatives[0].transcript;
					console.log(CustomQuery);
					$("#txtspeech").val(CustomQuery);
					CallDialogflowAPI();
				}
			},
			error: function (textStatus, errorMessage) { // error callback 
				console.log(errorMessage);
			}
		});
	}

	function CallCouldntHear() {
		console.log("User Did not Speak");
		var spokenResponse = messageCouldntHear;
		CallTextAPI(spokenResponse);
		$('#TextToDisplay').show();
		$("#txtspeech").val("");
		document.getElementById('myFrame').setAttribute('src', "");
	}
	// Google Text to Speech Method
	function CallTextAPI(Texttospeech) {
		console.log("Calling Text API");

		var jsontextobject =
			{
				input: {
					text: Texttospeech,
				},
				voice: {
					languageCode: "en-US",
					name: "en-US-Wavenet-C",
					ssmlGender: "FEMALE"
				},
				audioConfig: {
					audioEncoding: "MP3"
				}
			}
		var textJson = JSON.stringify(jsontextobject);

		// Google API Post Method.
		$.ajax({
			type: "POST",
			url: GoogleTextAPI,
			data: textJson,
			contentType: "application/json;",
			dataType: "json",
			success: function (data, status) {   // success callback function
				console.log(status);
				PayerStream(data);
			},
			error: function (textStatus, errorMessage) { // error callback 
				console.log(errorMessage);
			}
		});
	}

	function PayerStream(data) {
		var audio = document.getElementById('audio');
		audio.src = "data:audio/mp3;base64," + data.audioContent;
		audio.load();
		audio.play();
	}
	// Dialogflow API Post Method.
	function CallDialogflowAPI() {
		console.log("Calling Dialogflow API");
		$.ajax({
			type: "POST",
			url: DialogflowAPI + "query",
			contentType: "application/json;",
			dataType: "json",
			headers: { "Authorization": "Bearer " + accessToken },
			data: JSON.stringify({ query: CustomQuery, lang: "en", sessionId: "test" }),
			success: function (data, status) {// success callback function
				prepareResponse(data);
				console.log(status);
			},
			error: function (textStatus, errorMessage) {// error callback 
				console.log(errorMessage);
			}
		});
	}

	// Get resposne from Dialogflow API Post Method.
	function prepareResponse(val) {
		console.log("Getting resposne from Dialogflow API");
		var debugJSON = JSON.stringify(val, undefined, 2);
		var spokenResponse = val.result.fulfillment.speech;
		var IntentName = val.result.metadata.intentName;
		var AppName = val.result.parameters.applications;
		var Timeperiod = val.result.parameters.timings;
		var Resource = val.result.parameters.resources;

		if (val.result.contexts.length == 1) {
			DrillDownApp = val.result.contexts[0].parameters.applications;
			DrillDownTime = val.result.contexts[0].parameters.timings;
		}
		if (val.result.contexts.length > 1) {
			DrillDownTime = val.result.contexts[1].parameters.timings;
			DrillDownApp = val.result.contexts[1].parameters.applications;
		}

		var SmallTalk = val.result.action;
		if (IntentName != "" && IntentName != null) {
			CallTextAPI(spokenResponse);
			intentMatch(IntentName, AppName, Timeperiod, Resource, DrillDownApp, DrillDownTime);

		}
		else if (SmallTalk != "") {
			CallTextAPI(spokenResponse);
			document.getElementById('myFrame').setAttribute('src', "");
		}
	}
	function getTimePeriod(TimePeriod) {
		var timeperiod = TimePeriod.split(" ");
		if (timeperiod[0] == 24)
			timeperiod[0] = 6;
		if (timeperiod[0] == 8)
			timeperiod[0] = 5;
		return timeperiod;
	}
	// Dialogflow intent name matching.
	function intentMatch(IntentName, AppName, Timeperiod, Resource, DrillDownApp, DrillDownTime) {
		// graph Use case    
		if (IntentName == "Default Fallback Intent") {
		}
		else if (IntentName == "heatmap") {
			var loc;
			if (Timeperiod != null && Timeperiod != "") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "heatmap?timePeriod=" + timeperiod[0] + "&viewPoints=1";
			}
			else
				loc = GavelServiceAPI + "heatmap?timePeriod=3&viewPoints=1";
			document.getElementById('myFrame').setAttribute('src', loc);

		}
		else if (IntentName == "overall_health") {
			var loc;
			if (AppName != null && AppName != "") {
				var ApplicationName = "SMS Gateway"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards"
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				//var ApplicationName = "iCards"
				//if (ApplicationName.includes(AppName)) {
				//    if (Timeperiod != null && Timeperiod != "") {
				//        var timeperiod = getTimePeriod(Timeperiod);
				//        loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
				//    }
				//    else
				//        loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
				//    document.getElementById('myFrame').setAttribute('src', loc);
				//}
			}
			else {
				if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=" + timeperiod[0];
				}
				else
					loc = GavelServiceAPI + "overAllChart?state=all&timePeriod=3";
				document.getElementById('myFrame').setAttribute('src', loc);
			}

		}
		else if (IntentName == "application_summary") {
			var loc;
			if (AppName != null && AppName != "") {
				var ApplicationName = "SMS Gateway";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=SMS Gateway&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=SMS Gateway&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);

						loc = GavelServiceAPI + "alertsChart?state=all&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=Digital Banking Pockets&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=3D Secure&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=3D Secure&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=iLoans India&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=iLoans India&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=iCore India&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=iCore India&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=I Cards Online 4&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=I Cards Online 4&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "alertsChart?state=all&appName=I Cards Prime 4&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "alertsChart?state=all&appName=I Cards Prime 4&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}

		}
		else if (IntentName == "application_status - alerts") {
			var loc;
			if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
				var ApplicationName = "SMS Gateway";
				if (DrillDownApp != null && DrillDownApp != "") {
					AppName = DrillDownApp;
				}
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {

						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);

						loc = GavelServiceAPI + "allalerts?appId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";

				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[1] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[1] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);

						loc = GavelServiceAPI + "allalerts?appId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[5] + "&appName=" + "3D Secure" + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[5] + "&appName=" + "3D Secure" + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[6] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[6] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[9] + "&appName=iLoans India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[9] + "&appName=iLoans India&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[10] + "&appName=iCore India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[10] + "&appName=iCore India&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[17] + "&appName=I Cards Prime 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[17] + "&appName=I Cards Prime 4&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}
			else {
				if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=" + timeperiod[0] + "&viewPoints=1";
				}
				else
					loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=3&viewPoints=1";
			}
			document.getElementById('myFrame').setAttribute('src', loc);

		}
		else if (IntentName == "application_status - correlations") {
			var loc;

			if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
				var ApplicationName = "SMS Gateway";
				if (DrillDownApp != null && DrillDownApp != "") {
					AppName = DrillDownApp;
				}
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[1] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[1] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[4] + "&appName=" + AppName + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[5] + "&appName=3D Secure&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[5] + "&appName=3D Secure&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[6] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[6] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[9] + "&appName=iLoans India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[9] + "&appName=iLoans India&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[10] + "&appName=iCore India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[10] + "&appName=iCore India&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[17] + "&appName=I Cards Prime 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[17] + "&appName=I Cards Prime 4&timePeriod=3&viewPoints=1";
					}
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}
			else {
				if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=" + timeperiod[0] + "&viewPoints=1";
				}
				else
					loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=3&viewPoints=1";
				document.getElementById('myFrame').setAttribute('src', loc);
			}


		}
		else if (IntentName == "application_status") {
			var loc;
			if (AppName != null && AppName != "") {
				var ApplicationName = "SMS Gateway";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=SMS Gateway&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=SMS Gateway&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=Digital Banking Pockets&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=3D Secure&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=3D Secure&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=iLoans India&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=iLoans India&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=iCore India&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=iCore India&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=I Cards Online 4&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=I Cards Online 4&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "appsChart?state=all&appName=I Cards Prime 4&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=I Cards Prime 4&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}


		}
		else if (IntentName == "application_correlation") {
			var loc;
			if (AppName != null && AppName != "") {
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "correlationLists?alertId =" + Appid[3] + "&timePeriod=" + timeperiod[0];
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				else {
					loc = GavelServiceAPI + "correlationLists?alertId =" + Appid[3] + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				if (AppName != null && AppName != "") {
					var ApplicationName = "IMPS";
					if (ApplicationName.includes(AppName)) {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "correlationLists?alertId =" + Appid[4] + "&timePeriod=" + timeperiod[0];
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId =" + Appid[4] + "&timePeriod=3";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
			}

		}
		else if (IntentName == "application_risks") {
			var loc;
			if (AppName != null && AppName != "") {
				var ApplicationName = "SMS Gateway";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[1] + "&appName=SMS Gateway&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[5] + "&appName=3D Secure&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[6] + "&appName=3D Secure&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[9] + "&appName=iLoans India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[10] + "&appName=iCore India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=" + Appid[17] + "&appName=I Cards Online 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}
			else {
				if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				else
					loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=3&viewPoints=1";
				document.getElementById('myFrame').setAttribute('src', loc);
			}

		}
		else if (IntentName == "top10issues") {
			var loc;
			if (AppName != null && AppName != "") {
				var ApplicationName = "SMS Gateway";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=SMS Gateway&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=SMS Gateway";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=Digital Banking Pockets&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=Digital Banking Pockets";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=3D Secure&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=3D Secure";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);

						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=iLoans India&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=iLoans India";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=iCore India&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=iCore India";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);

						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=I Cards Online 4&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=I Cards Online 4";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if (Timeperiod != null && Timeperiod != "") {
						var timeperiod = getTimePeriod(Timeperiod);
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName + "&dateTime=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "top10Issues?appName=" + AppName;
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}
			else {
				if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "top10Issues?dateTime=" + timeperiod[0];
				}
				else
					loc = GavelServiceAPI + "top10Issues";
				document.getElementById('myFrame').setAttribute('src', loc);
			}

		}
		else if (IntentName == "overall_risk") {
			var loc;
			if (Timeperiod != null && Timeperiod != "") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "riskApps?dateTime=" + timeperiod[0];
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else {
				loc = GavelServiceAPI + "riskApps";
				document.getElementById('myFrame').setAttribute('src', loc);
			}

		}
		else if (IntentName == "overall_risk-applicationrisk") {
			var loc;

			if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
				var ApplicationName = "SMS Gateway";
				if (DrillDownApp != null && DrillDownApp != "") {
					AppName = DrillDownApp;
				}
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=SMS Gateway&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=SMS Gateway&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=Digital Banking Pockets&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=3D Secure&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=3D Secure&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=iLoans India&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=iLoans India&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=iCore India&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=iCore India&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=" + AppName + "&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=I Cards Online 4&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=I Cards Online 4&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "appsChart?state=all&appName=I Cards Prime 4&timePeriod=" + timeperiod[0];
					}
					else
						loc = GavelServiceAPI + "appsChart?state=all&appName=I Cards Prime 4&timePeriod=3";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}
			else {
				loc = GavelServiceAPI + "riskApps";//"appsChart?state=all&fromDate="+ +"&toDate="+;
				document.getElementById('myFrame').setAttribute('src', loc);
			}

		}
		else if (IntentName == "overall_correlation") {
			var loc;
			if (Timeperiod != null && Timeperiod != "") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=" + timeperiod[0];
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else {
				loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=3";
				document.getElementById('myFrame').setAttribute('src', loc);
			}

		}
		else if (IntentName == "overall_appsummary") {
			var loc;
			if (Timeperiod != null && Timeperiod != "") {
				var timeperiod = getTimePeriod(Timeperiod);
				loc = GavelServiceAPI + "alertsChart?state=all&timePeriod=" + timeperiod[0];
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else {
				loc = GavelServiceAPI + "alertsChart?state=all&timePeriod=3";
				document.getElementById('myFrame').setAttribute('src', loc);
			}

		}
		else if (IntentName == "overall_appstatus") {
			var loc;
			if (Timeperiod != null && Timeperiod != "") {
				loc = GavelServiceAPI + "appsChart?state=all&timePeriod=" + timeperiod[0];
				document.getElementById('myFrame').setAttribute('src', loc);
			}
			else {
				loc = GavelServiceAPI + "appsChart?state=all&timePeriod=3";
				document.getElementById('myFrame').setAttribute('src', loc);
			}

		}
		else if (IntentName == "overall_risk-applicationrisk_alerts") {
			var loc;
			if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
				var ApplicationName = "SMS Gateway";
				if (DrillDownApp != null && DrillDownApp != "") {
					AppName = DrillDownApp;
				}
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[1] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[1] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[5] + "&appName=" + "3D Secure" + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[5] + "&appName=" + "3D Secure" + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[6] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					}
					else
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[6] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[9] + "&appName=iLoans India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[9] + "&appName=iLoans India&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[10] + "&appName=iCore India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[10] + "&appName=iCore India&timePeriod=3&viewPoints=1";

						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";

						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";

						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[17] + "&appName=I Cards Prime 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "allalerts?appId=" + Appid[17] + "&appName=I Cards Prime 4&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
			}
			else {
				if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				else {
					loc = GavelServiceAPI + "allalerts?appId=ALL&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}

		}
		else if (IntentName == "overall_risk-applicationrisk_correlations") {
			var loc;
			if ((AppName != null && AppName != "") || (DrillDownApp != null && DrillDownApp != "")) {
				var ApplicationName = "SMS Gateway";
				if (DrillDownApp != null && DrillDownApp != "") {
					AppName = DrillDownApp;
				}
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[0] + "&appName=SMS Gateway&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iView";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[1] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[1] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "RIB";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[2] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "DBP";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[3] + "&appName=Digital Banking Pockets&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "IMPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[4] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "3DSecure";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[5] + "&appName=3D Secure&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[5] + "&appName=3D Secure&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "Riskfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[6] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[6] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iMobile";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[7] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "Webfort";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[8] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iLoans";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[9] + "&appName=iLoans India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[9] + "&appName=iLoans India&timePeriod=3&viewPoints=1";

						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iCore";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[10] + "&appName=iCore India&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[10] + "&appName=iCore India&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "EAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[11] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "IAI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[12] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "UPI";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[13] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "CAR";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[14] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "UBPS";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[15] + "&appName=" + AppName + "&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "iCards";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[16] + "&appName=I Cards Online 4&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
				var ApplicationName = "I Cards Prime 4";
				if (ApplicationName.includes(AppName)) {
					if ((Timeperiod != null && Timeperiod != "") || (DrillDownTime != null && DrillDownTime != "")) {
						var timeperiod;
						if (Timeperiod != null && Timeperiod != "")
							timeperiod = getTimePeriod(Timeperiod);
						else
							timeperiod = getTimePeriod(DrillDownTime);
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[17] + "&appName=I Cards Prime 4&timePeriod=" + timeperiod[0] + "&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
					else {
						loc = GavelServiceAPI + "correlationLists?alertId=" + Appid[17] + "&appName=I Cards Prime 4&timePeriod=3&viewPoints=1";
						document.getElementById('myFrame').setAttribute('src', loc);
					}
				}
			}
			else {
				if (Timeperiod != null && Timeperiod != "") {
					var timeperiod = getTimePeriod(Timeperiod);
					loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=" + timeperiod[0] + "&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
				else {
					loc = GavelServiceAPI + "correlationLists?alertId=ALL&timePeriod=3&viewPoints=1";
					document.getElementById('myFrame').setAttribute('src', loc);
				}
			}


		}
		DrillDownApp = "";
		DrillDownTime = "";

		//-----*************Transaction Intent***************----------------------------
		// if (IntentName == "application_transactions") {
		//    if (Resource != null && Resource != "") {
		//        if (AppName != null && AppName != "") {
		//            var ApplicationName = "SMS Gateway"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[0] + "&layerId=1,2,3,4,5&appStatus=0&layerName=SMS%20Gateway&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[0] + "&layerId=1,2,3,4,5&appStatus=0&layerName=SMS%20Gateway&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[0] + "&layerId=1,2,3,4,5&appStatus=0&layerName=SMS%20Gateway&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[0] + "&layerId=1,2,3,4,5&appStatus=0&layerName=SMS%20Gateway&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[0] + "&layerId=1,2,3,4,5&appStatus=0&layerName=SMS%20Gateway&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "iView"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[1] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iView&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[1] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iView&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[1] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iView&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[1] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iView&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[1] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iView&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "RIB"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[2] + "&layerId=1,2,3,4,5&appStatus=0&layerName=RIB&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[2] + "&layerId=1,2,3,4,5&appStatus=0&layerName=RIB&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[2] + "&layerId=1,2,3,4,5&appStatus=0&layerName=RIB&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[2] + "&layerId=1,2,3,4,5&appStatus=0&layerName=RIB&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[2] + "&layerId=1,2,3,4,5&appStatus=0&layerName=RIB&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "DBP"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[3] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Digital%20Banking%20Pockets&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[3] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Digital%20Banking%20Pockets&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[3] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Digital%20Banking%20Pockets&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[3] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Digital%20Banking%20Pockets&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[3] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Digital%20Banking%20Pockets&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "IMPS"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[4] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IMPS&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[4] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IMPS&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[4] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IMPS&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[4] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IMPS&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[4] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IMPS&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "3DSecure"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[5] + "&layerId=1,2,3,4,5&appStatus=0&layerName=3D%20Secure&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[5] + "&layerId=1,2,3,4,5&appStatus=0&layerName=3D%20Secure&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[5] + "&layerId=1,2,3,4,5&appStatus=0&layerName=3D%20Secure&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[5] + "&layerId=1,2,3,4,5&appStatus=0&layerName=3D%20Secure&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[5] + "&layerId=1,2,3,4,5&appStatus=0&layerName=3D%20Secure&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "Riskfort"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[6] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Riskfort&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[6] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Riskfort&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[6] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Riskfort&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[6] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Riskfort&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[6] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Riskfort&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "iMobile"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[7] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iMobile&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[7] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iMobile&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[7] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iMobile&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[7] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iMobile&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[7] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iMobile&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "Webfort"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[8] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Webfort&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[8] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Webfort&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[8] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Webfort&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[8] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Webfort&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[8] + "&layerId=1,2,3,4,5&appStatus=0&layerName=Webfort&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "iLoans"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[9] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iLoans&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[9] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iLoans&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[9] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iLoans&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[9] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iLoans&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[9] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iLoans&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "iCore"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[10] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCore&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[10] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCore&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[10] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCore&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[10] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCore&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[10] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCore&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "EAI"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[11] + "&layerId=1,2,3,4,5&appStatus=0&layerName=EAI&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[11] + "&layerId=1,2,3,4,5&appStatus=0&layerName=EAI&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[11] + "&layerId=1,2,3,4,5&appStatus=0&layerName=EAI&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[11] + "&layerId=1,2,3,4,5&appStatus=0&layerName=EAI&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[11] + "&layerId=1,2,3,4,5&appStatus=0&layerName=EAI&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "IAI"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[12] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IAI&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[12] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IAI&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[12] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IAI&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[12] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IAI&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[12] + "&layerId=1,2,3,4,5&appStatus=0&layerName=IAI&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "UPI"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[13] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UPI&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[13] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UPI&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[13] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UPI&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[13] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UPI&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[13] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UPI&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "CAR"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[14] + "&layerId=1,2,3,4,5&appStatus=0&layerName=CAR&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[14] + "&layerId=1,2,3,4,5&appStatus=0&layerName=CAR&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[14] + "&layerId=1,2,3,4,5&appStatus=0&layerName=CAR&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[14] + "&layerId=1,2,3,4,5&appStatus=0&layerName=CAR&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[14] + "&layerId=1,2,3,4,5&appStatus=0&layerName=CAR&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "UBPS"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[15] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UBPS&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[15] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UBPS&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[15] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UBPS&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[15] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UBPS&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[15] + "&layerId=1,2,3,4,5&appStatus=0&layerName=UBPS&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "iCards"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[16] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[16] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[16] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[16] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[16] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//            var ApplicationName = "iCards"
		//            if (ApplicationName.includes(AppName)) {
		//                if (Resource == "APM") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[17] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=1";
		//                }
		//                if (Resource == "server") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[17] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=2";
		//                }
		//                if (Resource == "database") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[17] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=3";
		//                }
		//                if (Resource == "network") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[17] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=4";
		//                }
		//                if (Resource == "storage") {
		//                    var loc = GavelServiceAPI + "toolDetails?appId=" + Appid[17] + "&layerId=1,2,3,4,5&appStatus=0&layerName=iCards&drillDownId=5";
		//                }
		//                document.getElementById('myFrame').setAttribute('src', loc);
		//            }
		//        }
		//    }
		//}
	}
});
